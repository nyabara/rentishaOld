package com.example.rentisha

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.rentisha.data.DataSource
import com.example.rentisha.databinding.FragmentHouseDetailBinding
import com.example.rentisha.databinding.FragmentHouseListBinding
import com.example.rentisha.model.House
import java.lang.reflect.Field


class HouseDetailFragment : Fragment() {
    companion object {
        const val HOUSEID = "houseid"
    }
    private var _binding: FragmentHouseDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var houseId: String
    private lateinit var itemImage: ImageView
    private lateinit var itemTitle: TextView
    private lateinit var houseReview: TextView
    private lateinit var houseDescription: TextView
    private lateinit var housePlace: TextView
    private lateinit var housePrice: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            houseId = it.getString(HOUSEID).toString()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentHouseDetailBinding.inflate(inflater,container,false)
        val view =binding.root
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadDetails()
    }

    private fun loadDetails(){
        val houses = DataSource().loadRents()
        val resId =getStringResourceId(houseId)

        Log.d("resId",houses.toString())
        Log.d("resId",houseId)
        Log.d("resId",resId.toString())

        val filteredHouse:List<House> = houses.filter {
            it.houseNumber==resId
        }
        val house = filteredHouse[0]
        Log.d("houseObject",house.toString())
        itemTitle = binding.itemTitle
        itemTitle.text = houseId
        itemImage = binding.itemImage
        itemImage.setImageResource(house.imageResourceId)
        houseReview = binding.houseReview
        houseReview.text = house.houseReview
        houseDescription = binding.houseDescription
        houseDescription.text = house.houseDescription
        housePlace = binding.housePlace
        housePlace.text = house.housePlace
        housePrice = binding.housePrice
        housePrice.text = house.housePrice
    }

    fun getStringResourceId(stringToSearch: String): Int {
        val fields: Array<Field> = R.string::class.java.fields
        for (field in fields) {
            val id = field.getInt(field)
            val str = resources.getString(id)
            if (str == stringToSearch) {
                return id
            }
        }
        return -1
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}