package com.example.rentisha.adapter

class HouseDetailAdapter {
}