package com.example.rentisha.data

import android.content.Context
import com.example.rentisha.MainActivity
import com.example.rentisha.R
import com.example.rentisha.model.House
import com.example.rentisha.place.Place
import com.example.rentisha.place.PlacesReader

class DataSource {
    fun loadRents():List<House>{
        val rentList = listOf<House>(
            House(R.string.rentisha1,R.drawable.image1,"(No review)","Nyamira 1st Avenue, 5 Creek Villa","Nyamira","Ksh15,000/Month"),
            House(R.string.rentisha2,R.drawable.image2,"(No review)","3 BEDROOM APARTMENT IN KISUMU","Kisumu","Ksh15,000/Month"),
            House(R.string.rentisha3,R.drawable.image3,"(No review)","Lovely 2 Bedroom Rental on Beachfront with Pool","Mombasa","Ksh50,000/Month"),
            House(R.string.rentisha4,R.drawable.image4,"(No review)","3 BEDROOM APARTMENT WITH SWIMMING POOL","Nairobi","Ksh70,000/Month"),
            House(R.string.rentisha5,R.drawable.image5,"(No review)","Bluetique Beach House","Kikambala Kenya","Ksh55,000/Month"),
            House(R.string.rentisha6,R.drawable.image6,"(No review)","Shikara Apartment A3","Nyali,Mombasa","Ksh44,000/Month"),
            House(R.string.rentisha7,R.drawable.image7,"(No review)","Royal B5 Apartments in Bungoma","Bungoma","Ksh18,000/Month"),
            House(R.string.rentisha8,R.drawable.image8,"(No review)","Spacious Two Bedroom Home with Pool","Kisii","Ksh46,000/Month"),
            House(R.string.rentisha9,R.drawable.image9,"(No review)","Exquisite 3-bedroomed Entire Apartment","Nakuru","Ksh30,000/Month"),
            House(R.string.rentisha10,R.drawable.image10,"(No review)","Njoro Vegas Apartment","Njoro","Ksh15,000/Month"))
        return rentList

    }
}