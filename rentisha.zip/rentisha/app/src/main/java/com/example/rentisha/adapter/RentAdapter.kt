package com.example.rentisha.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.rentisha.DetailActivity
import com.example.rentisha.HouseListFragment
import com.example.rentisha.HouseListFragmentDirections
import com.example.rentisha.R
import com.example.rentisha.model.House

class RentAdapter(val context: Context, private val dataset: List<House>) : RecyclerView.Adapter<RentAdapter.RentViewHolder>() {

    class RentViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val textView: TextView = view.findViewById(R.id.item_title)
        val imageView: ImageView = view.findViewById(R.id.item_image)
        val houseReview:TextView = view.findViewById(R.id.house_review)
        val houseDescription:TextView = view.findViewById(R.id.house_description)
        val housePlace:TextView = view.findViewById(R.id.house_place)
        val housePrice:TextView = view.findViewById(R.id.house_price)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RentViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)
        return RentViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: RentViewHolder, position: Int) {
        val rent = dataset[position]
        holder.textView.text = context.resources.getString(rent.houseNumber)
        holder.imageView.setImageResource(rent.imageResourceId)
        holder.houseReview.text = rent.houseReview
        holder.houseDescription.text = rent.houseDescription
        holder.housePlace.text = rent.housePlace
        holder.housePrice.text = rent.housePrice


        holder.imageView.setOnClickListener {
           /* val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra(DetailActivity.HOUSEID,holder.textView.text.toString())
            context.startActivity(intent)*/
            val action = HouseListFragmentDirections.actionHouseListFragmentToHouseDetailFragment(houseid = holder.textView.text.toString())
            holder.view.findNavController().navigate(action)
        }
    }

    override fun getItemCount(): Int {
        return dataset.size
    }
}