package com.example.rentisha.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class House(
    @StringRes val houseNumber:Int,
    @DrawableRes val imageResourceId: Int,
    val houseReview:String,
    val houseDescription:String,
    val housePlace:String,
    val housePrice:String
)
