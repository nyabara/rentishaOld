package com.example.rentisha

import android.content.Context
import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.rentisha.data.DataSource
import com.example.rentisha.databinding.ActivityDetailBinding
import com.example.rentisha.databinding.ActivityMainBinding
import com.example.rentisha.model.House
import com.google.android.gms.common.util.ArrayUtils.contains
import java.lang.reflect.Field


class DetailActivity : AppCompatActivity() {
    companion object {
        const val HOUSEID = "houseid"
    }
    private var _binding: ActivityDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var houseId: String
    private lateinit var itemImage: ImageView
    private lateinit var itemTitle: TextView
    private lateinit var houseReview: TextView
    private lateinit var houseDescription: TextView
    private lateinit var housePlace: TextView
    private lateinit var housePrice: TextView




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        houseId= intent?.extras?.getString(DetailActivity.HOUSEID).toString()



        loadDetails()


    }

    private fun loadDetails(){
        val houses = DataSource().loadRents()
        val resId =getStringResourceId(houseId)

        Log.d("resId",houses.toString())
        Log.d("resId",houseId)
        Log.d("resId",resId.toString())

        val filteredHouse:List<House> = houses.filter {
            it.houseNumber==resId
             }
        val house = filteredHouse[0]
        Log.d("houseObject",house.toString())
        itemTitle = binding.itemTitle
        itemTitle.text = houseId
        itemImage = binding.itemImage
        itemImage.setImageResource(house.imageResourceId)
        houseReview = binding.houseReview
        houseReview.text = house.houseReview
        houseDescription = binding.houseDescription
        houseDescription.text = house.houseDescription
        housePlace = binding.housePlace
        housePlace.text = house.housePlace
        housePrice = binding.housePrice
        housePrice.text = house.housePrice





    }
    fun getStringResourceId(stringToSearch: String): Int {
        val fields: Array<Field> = R.string::class.java.fields
        for (field in fields) {
            val id = field.getInt(field)
            val str = resources.getString(id)
            if (str == stringToSearch) {
                return id
            }
        }
        return -1
    }

}